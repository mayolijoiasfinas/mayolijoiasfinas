---
name: Mayoli app architecture
description: Key non-obvious decisions for the Mayoli Joias Finas ERP app (artifacts/mayoli).
---

## Core rule
This app has NO backend. All persistence is localStorage via `StoreContext`. Never add API calls or a database unless the user explicitly requests it.

**Why:** The user explicitly required localStorage-only persistence for offline/mobile use as a PWA.

**How to apply:** Any new feature stores and reads from the existing 6 keys in StoreContext (`mayoli_products`, `mayoli_customers`, `mayoli_sales`, `mayoli_catalogs`, `mayoli_expenses`, `mayoli_settings`).

## Stock status rule
`status` is always derived — never set manually by the user. Rule: `null qty → untracked`, `0 → out`, `(initialQuantity > 1 && qty === 1) → ending`, else `available`. Run on every `addProduct` / `updateProduct`.

**Why:** The "Acabando" rule only applies to pieces originally stocked with more than 1 unit.

## Conditional ("malinha") flow
Sending conditional decrements stock normally. On reconciliation: returned items have quantity restored (+1) and status recalculated; purchased items create a new Sale via `addSale`. The original conditional Sale is marked `status: 'paid', isConditional: false`.

## PWA icons
Icons were generated with pure Node.js using `zlib.deflateSync` — no external packages. If icons need regeneration, the script is in project history (simple PNG writer, rose bg + gold gem shape).

## Vite HMR quirk
When a new Radix UI component is first used (e.g. `@radix-ui/react-label`), Vite re-optimizes it mid-session, causing a `useState` null crash. Fix: restart the mayoli workflow — clears HMR state and optimizes cleanly on fresh start.
